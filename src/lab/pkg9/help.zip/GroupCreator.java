/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab.pkg9;

import java.util.UUID;

/**
 *
 * @author Mahmoud Waleed
 */
public class GroupCreator {
     private final Database database = DatabaseFactory.createDatabase();
     public void createGroup(User user, String groupName, String description, String imagePath) {
        String groupId = generateUniqueId("Group");
        Group newGroup = new Group(groupId, user.getUserId(), imagePath, groupName, description);
        GroupManager groupManager = GroupManagerFactory.createGroupManager(user, "Admin");
        groupManager.joinGroup(newGroup);
        database.saveUsersToFile();
    }
        private String generateUniqueId(String prefix) {
        return prefix + "ID" + UUID.randomUUID();
    }
}
